import React from "react";
import Form from "./Form";

function Home() {

  return (
    <div className="h-screen w-screen flex justify-center items-center bg-blue-400">
        <Form />
    </div>
  )
}

export default Home;
